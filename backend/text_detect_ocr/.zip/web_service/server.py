from flask import Flask, request, jsonify
import os
import sys
sys.path.append('/data1/home/sonnh/work/LLM')
import os
from time import time
from full_request import Processor
import base64
import numpy as np
import cv2

def base64_to_image(string_bytes):
	im_bytes = base64.b64decode(string_bytes)
	im_arr = np.frombuffer(im_bytes, dtype=np.uint8)
	image = cv2.imdecode(im_arr, flags=cv2.IMREAD_COLOR)
	return image
    
processor = Processor()

app = Flask(__name__)

@app.route("/")
def main():
    data = "hello world"
    return jsonify({'data': data}) 

@app.route('/extract', methods=['POST'])
def extract():
    base64_image = request.json["image"]
    image = base64_to_image(base64_image)
    s = time()
    output_json = processor.predict(image)
    e = time()
    print(output_json)
    respone = {'respone':output_json, 'runtime':'%.3f'%(e-s)}
    return jsonify(respone)

if __name__ == '__main__':
    app.run(debug=True, port=5001, host='0.0.0.0')