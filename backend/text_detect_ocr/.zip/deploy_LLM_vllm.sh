# model=data/Qwen1.5-0.5B_finetuned
# # model=/data/models--meta-llama--Meta-Llama-3-8B-Instruct/snapshots/1448453bdb895762499deb4176c1dd83b145fac1/
# model=data/models--Viet-Mistral--Vistral-7B-Chat/snapshots/d331b64e61b935cc43c2b3010ae9fb4fde599b45/
model=data/Viet-Mistral/Vistral-7B-Chat-AWQ/ 
volume=$PWD/data # share a volume with the Docker container to avoid downloading weights every run

# sudo docker run --gpus 0 \
#     -v $volume:/data \
#     -p 8880:80 --shm-size 1g \
#     vllm/vllm-openai:v0.4.1 \
#     --model $model
python -m vllm.entrypoints.openai.api_server --host 0.0.0.0 --port 6007 \
    --model $model --tokenizer $model --dtype float16 \
    --max-model-len 4096 --max-num-batched-tokens 4096 \
    --max-num-seqs 4096 \
    --gpu-memory-utilization 0.8
    
# --chat-template CHAT_TEMPLATE The file path to the chat template, or the template in single-line form for the specified model                                                    
