import sys
sys.path.append('/data1/home/sonnh/work/LLM')
import os
os.environ['CUDA_VISIBLE_DEVICES']='0'
import cv2
import numpy as np
from text_detect_ocr.text_detector import TextDetector
from text_detect_ocr.ocr import OCR
from text_detect_ocr.postprocessor import PostProcessor

# from text_generation import Client
from time import time
import json
import pdb
from transformers import AutoTokenizer
from openai import OpenAI


# #===== KUNN =====
# field_names = ','.join(['số hợp đồng tín dụng', 'số khế ước nhận nợ', 'tên bên vay', 'số chứng minh nhân dân của bên vay',
#                             'tên người đại diện bên vay', 'số chứng minh nhân dân của người đại diện bên vay',
#                             'tên bên cho vay', 'số tiền vay', 'hạn mức vay', 'lãi suất vay', 'ngày giải ngân',
#                             'ngày đến hạn trả nợ', 'ngày trả lãi'])
# field_keys = ','.join(['debt_agreement_number', 'credit_agreement_number', 'borrower_name', 'borrower_id',
#                           'borrower_representer', 'borrower_registration_number', 'lender_name', 'money', 'debt_limit',
#                           'interest_rate', 'release_date', 'loan_term', 'interest_payment_schedule'])
# sample_json = {
#         "debt_agreement_number": "...", "credit_agreement_number": "..." ,
#         "lender_name": "...", "debt_limit": "..." ,
#         "money": "...", "interest_rate": "..." ,
#         "release_date": "...", "loan_term": "..." ,
#         "interest_payment_schedule": "...", "borrower_name": "..." ,
#         "borrower_id": "...", "borrower_representer": "..." ,
#         "borrower_registration_number": "...",
#     }
# ===== VAT B1 =====
viet_fields = ['loại giấy tờ', 'ngày hóa đơn', 'kí hiệu', 'số hóa đơn', 'tên của đơn vị bán',
               'mã số thuế (MST) của đơn vị bán', 'địa chỉ đơn vị bán', 'số điện thoại của đơn vị bán',
               'tên ngân hàng của đơn vị bán', 'website của đơn vị bán', 'số tài khoản của đơn vị bán',
               'tên của đơn vị mua', 'mã số thuế (MST) của đơn vị mua', 'tổng tiền thuế',
               'tổng tiền thanh toán', 'kí bởi', 'kí ngày']

eng_fields = ['doc_type', 'doi', 'sign', 'invoice_number', 'provider_name', 'provider_tax', 'provider_add',
              'provider_phone', 'provider_bank', 'provider_web', 'provider_bank_acc', 'customer_name',
              'customer_tax', 'vat_amount', 'total_amount', 'sign_name', 'sign_date']

def apply_format(text, viet_fields, eng_fields):
    field_names = ','.join(viet_fields)
    field_keys  = ','.join(eng_fields)
    # prompt_prefix = f"""{text}
    # --------------------------
    # Lấy ra thông tin về {field_names} ứng với {field_keys} từ đoạn trên. Bắt buộc output ở định dạng JSON.
    # JSON đó phải có dạng như sau:"""
    prompt_prefix = f"""Lấy ra thông tin về {field_names} ứng với {field_keys} từ đoạn trên. Bắt buộc output ở định dạng JSON.\n JSON đó phải có dạng như sau:"""
    
    sample_json = {key:'...' for key in eng_fields}
    
    prompt_posfix = 'Nếu trường thông tin không tồn tại, hãy để trống. Lưu ý mỗi trường chỉ xuất hiện duy nhất một lần'
    prompt = prompt_prefix + json.dumps(sample_json) + prompt_posfix +'\n'+text
    return prompt
    

class Processor:
    def __init__(self):
        MODEL_ROOT = '/data1/home/sonnh/work/LLM'
        model_cfg = {
        'text_detection': {
            'model_path': os.path.join(MODEL_ROOT, 'text_detect_ocr/models/text_detection/epoch=43_val_total_loss=0.66.onnx')
        },
        'ocr': {
            'model_path': os.path.join(MODEL_ROOT, 'text_detect_ocr/models/ocr/onnx_print_v4_batch8.onnx'),
            'max_sequence_length': 31,
            'charset' : "&1#@'()+,-./0123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ_`abcdefghijklmnopqrstuvwxyz<>ÀÁÂÃÇÈÉÊÌÍÒÓÔÕÙÚÝàáâãçèéêìíòóôõùúýĂăĐđĨĩŨũƠơƯưẠạẢảẤấẦầẨẩẪẫẬậẮắẰằẲẳẴẵẶặẸẹẺẻẼẽẾếỀềỂểỄễỆệỈỉỊịỌọỎỏỐốỒồỔổỖỗỘộỚớỜờỞởỠỡỢợỤụỦủỨứỪừỬửỮữỰựỲỳỴỵỶỷỸỹ’“”;* $%",
            'max_batch_size': 8,
        },
        'postprocess': {}
        }
        common_cfg = {}

        self.common_cfg = common_cfg
        self.model_cfg = model_cfg
        self.modules = [
            TextDetector(common_cfg, model_cfg['text_detection']),
            OCR(common_cfg, model_cfg['ocr']),
            PostProcessor(common_cfg, model_cfg['postprocess'])
        ]
        ##LLM
        ## ==== WITH vLLM ==== ##
        # Set OpenAI's API key and API base to use vLLM's API server.
        openai_api_key = "EMPTY"
        openai_api_base = "http://0.0.0.0:6007/v1"
        
        self.client = OpenAI(
            api_key=openai_api_key,
            base_url=openai_api_base,
        )

        # self.model_id = 'data/Qwen1.5-0.5B_finetuned'
        self.model_id = 'data/Viet-Mistral/Vistral-7B-Chat-AWQ/'

        ## ==== WITH TGI ==== ###
        # model_id = "meta-llama/Meta-Llama-3-8B-Instruct"
        # model_id = 'Viet-Mistral/Vistral-7B-Chat'
        # self.tokenizer = AutoTokenizer.from_pretrained(model_id)
        # self.llm_client = Client("http://127.0.0.1:8880", timeout=60)
        # pdb.set_trace()
        system_prompt = "Bạn là một trợ lí Tiếng Việt nhiệt tình và trung thực. Hãy luôn trả lời một cách hữu ích nhất có thể, đồng thời giữ an toàn.\n"
        system_prompt += "Câu trả lời của bạn không nên chứa bất kỳ nội dung gây hại, phân biệt chủng tộc, phân biệt giới tính, độc hại, nguy hiểm hoặc bất hợp pháp nào. Hãy đảm bảo rằng các câu trả lời của bạn không có thiên kiến xã hội và mang tính tích cực."
        system_prompt += "Nếu một câu hỏi không có ý nghĩa hoặc không hợp lý về mặt thông tin, hãy giải thích tại sao thay vì trả lời một điều gì đó không chính xác. Nếu bạn không biết câu trả lời cho một câu hỏi, hãy trả lời là bạn không biết và vui lòng không chia sẻ thông tin sai lệch."

        self.system_prompt = system_prompt
        
    def predict(self, image):
        # image = cv2.imread(file_path)
        # assert image is not None, 'image path not found !'
        result = {}
        result['orig_img'] = image
        for module in self.modules:
            result = module.predict(result)

        prompt = apply_format(result, viet_fields, eng_fields)
        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": prompt},
        ]
        ## ==== WITH TGI ==== ##
        # input_text = self.tokenizer.apply_chat_template(
        #     messages, tokenize=False
        # )
    
        # output_text = self.llm_client.generate(input_text, max_new_tokens=768,
        #     do_sample=True, temperature=0.1, top_p=0.95, top_k=40, repetition_penalty=1.05,).generated_text
        
        ## ===== WITH vLLM ==== ## 
        chat_response = self.client.chat.completions.create(
            max_tokens=512, temperature=0.95, top_p=0.7,
            model=self.model_id,
            messages = messages
        )
        output_text = chat_response.choices[0].message.content
        # print(output_text)
        # output_json = json.loads(output_text.replace('\'', '"'))
        try:
            output_text.replace('\n', '')
            output_json = json.loads(output_text)
        except:
            output_json = {'Error': "Model trả ra sai định dạng json", 'Raw_text': output_text}
        output_json['ocr'] = result
        return output_json
